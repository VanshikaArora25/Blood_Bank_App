package com.example.bb.email;

public class Util {

    public static final String EMAIL = "vanshika193174@dei.ac.in";
    public static final String PASSWORD = "";
}
